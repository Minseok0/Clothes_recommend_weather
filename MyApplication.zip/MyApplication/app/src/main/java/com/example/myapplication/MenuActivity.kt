package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.layout_menu.*

class MenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layout_menu)


        cloth_recommendation.setOnClickListener {
            val intent = Intent(this,ClothActivity::class.java)
            startActivity(intent)
        }
        estimation.setOnClickListener{
            val intent = Intent(this,EstimationActivity::class.java)
            startActivity(intent)
        }
        user_sensitivity.setOnClickListener{
            val intent = Intent(this,UserActivity::class.java)
            startActivity(intent)
        }
    }

}

