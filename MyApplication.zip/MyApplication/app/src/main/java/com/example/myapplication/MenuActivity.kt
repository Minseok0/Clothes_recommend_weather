package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.layout_menu.*

class MenuActivity : AppCompatActivity() {
    //private val preference: SharedPreferences? by lazy {getSharedPreferences("EnstimationActivity", MODE_PRIVATE)}
    //private val allEntries : MutableMap<String, Float> = (preference?.all ?: emptyMap<String, Float>()) as MutableMap<String, Float>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layout_menu)

        /*
        var sum = 0F
        var num = 0F
        if (allEntries.isEmpty()){
            sum = 3F
            num = 1F
        }
        else {
            for((index,value) in allEntries){
                    sum += value
                    num += 1F
            }
        }
        var result = sum / num

        intent.putExtra("sensitivity",result)
        Toast.makeText(applicationContext,"유저 민감도 : ${result}입니다.",Toast.LENGTH_SHORT).show()
        */

        cloth_recommendation.setOnClickListener {
            val intent = Intent(this,ClothActivity::class.java)
            startActivity(intent)
        }
        estimation.setOnClickListener{
            val intent = Intent(this,EstimationActivity::class.java)
            startActivity(intent)
        }
        user_sensitivity.setOnClickListener{}
    }
}

