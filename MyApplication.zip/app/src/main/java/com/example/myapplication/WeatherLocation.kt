package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.AsyncTask
import com.example.myapplication.databinding.ActivityMainBinding
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONObject
import java.lang.Exception
import java.net.URL
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.location.LocationRequest
import android.os.Looper
import android.util.Log
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationResult
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.Math.abs

class MainActivity : AppCompatActivity() { //전 파일의 클래스 그대로 옮겨온거임(수정)

    private lateinit var mBinding: ActivityMainBinding
    val KEY: String = "zermksAIRj%2BjSA4qXmTMtwB56UEA7mUA4tK5YYJMqT5ff26baEyM8Xs57%2BbcDUK%2Bb4pQ25rdEE2b33Lhy6CeZw%3D%3D" //키값(가능하면 숨기기)
    var num_of_rows = 100 // 몇개 가져올건지 정하는거(임시로 100개로 해놓음)
    var page_no = 1
    var base_time = "0500" // 문자열이다 조심
    var base_date = 20211113 // Integer임 아마
    var nx = "55" // 위도값(동적으로 받아올 예정)
    var ny = "127" // 경도값(동적으로 받아올 예정)
    var timenow = "0700"  // 현재시간을 0700 0730 이런식으로 0829 -> 0800 (문자열이다. 조심)
    var today = 20211113  // 이런식으로 (Integer임 아마, 원하는 날짜 넣으면 될것임)

    lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    lateinit var locationRequest: LocationRequest

    private var PERMISSION_ID = 1000 // 아무거나 괜춘, 정수기만 하면됨

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        getPos.setOnClickListener{ // getPos는 만들었던 파일의 버튼 id였음(변경좀)
            getLastLocation() // 위치 받아오는 함수
        }
    }

    //여기부터 위치 받아오는데 필요한 함수들
    @SuppressLint("MissingPermission")
    private fun getLastLocation(){
        if(CheckPerm()){
            if(isLocatioonEnabled()){
                //실제로 위치 받는곳
                fusedLocationProviderClient.lastLocation.addOnCompleteListener { task->
                    var location=task.result
                    if(location == null){
                        GetNewLocation()
                    }else{
                        Locationtxt.text = "현재위치는 : \n 위도 : " + location.latitude + "경도 : " + location.longitude //Locationtxt는 전에 받아오던 위치 id
                        nx = kotlin.math.abs(location.latitude.toInt()).toString()
                        ny = kotlin.math.abs(location.longitude.toInt()).toString()
                        weatherTask().execute() // 날씨 받아오는 함수
                    }
                }
            }else{
                Toast.makeText(this, "권한을 허용에 주십시요", Toast.LENGTH_SHORT).show()
            }
        }else{
            RequestPerm()
        }
    }

    @SuppressLint("MissingPermission")
    private fun GetNewLocation() {
        var locationRequest = com.google.android.gms.location.LocationRequest()
        locationRequest.priority = com.google.android.gms.location.LocationRequest.PRIORITY_HIGH_ACCURACY
        locationRequest.interval = 0
        locationRequest.fastestInterval = 0
        locationRequest.numUpdates = 1
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        fusedLocationProviderClient!!.requestLocationUpdates(
            locationRequest,locationCallback,Looper.myLooper()
        )
    }

    private val locationCallback = object : LocationCallback(){
        override fun onLocationResult(locationResult: LocationResult) {
            var lastLocation: Location = locationResult.lastLocation
            Log.d("Debug : ", "마지막 위치 : " + lastLocation.longitude.toString())
            Locationtxt.text = "현재위치는 \n 위도 : " + lastLocation.longitude + "경도 : " + lastLocation.latitude //Locationtxt는 전에 받아오던 위치 id
            nx = kotlin.math.abs(lastLocation.latitude.toInt()).toString()
            ny = kotlin.math.abs(lastLocation.longitude.toInt()).toString()
            weatherTask().execute() // 날씨 받아오는 함수
        }
    }

    //허용권한 확인
    private fun CheckPerm():Boolean{
        if(
            ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED ||
            ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
        ){
            return true
        }
        return false
    }
    //허용요청
    private fun RequestPerm(){
        ActivityCompat.requestPermissions(
            this, arrayOf(android.Manifest.permission.ACCESS_COARSE_LOCATION,android.Manifest.permission.ACCESS_FINE_LOCATION),
            PERMISSION_ID
        )
    }
    //locationService가 사용가능한지 확인
    private fun isLocatioonEnabled():Boolean{

        var locationManager:LocationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    //permission result checking
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode == PERMISSION_ID){
            if(grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Log.d("Debug:", "권한이 있습니다")
            }
        }
    }

    //여기부터 날씨데이터 받아오는 함수들
    inner class weatherTask() : AsyncTask<String, Void, String>() {

        override fun doInBackground(vararg p0: String?): String? {
            var response:String?
            try {
                response = URL("http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getVilageFcst?serviceKey=$KEY&pageNo=$page_no&numOfRows=$num_of_rows&dataType=JSON&base_date=$base_date&base_time=$base_time&nx=$nx&ny=$ny")
                    .readText(Charsets.UTF_8)
            }
            catch (e: Exception) {
                response = null
            }
            return response
        }

        @SuppressLint("SetTextI18n")
        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            try {
                val jsonObj = JSONObject(result)
                val jsonObj2 = jsonObj.getJSONObject("response")
                val jsonObj3 = jsonObj2.getJSONObject("body")
                val jsonObj4 = jsonObj3.getJSONObject("items")
                val jsonObj5 = jsonObj4.getJSONArray("item")
                var num=0
                for(i in 0 until num_of_rows){
                    val item_list=jsonObj5.getJSONObject(i)
                    val list_time=item_list.getString("fcstTime")
                    val list_date=item_list.getInt("fcstDate")
                    if(list_time == timenow && list_date == today){
                        num=i
                        break
                    }
                }
                var tmp:String? = null
                var uuu:String? = null
                var vvv:String? = null
                var vec:String? = null
                var wsd:String? = null
                var sky:String? = null
                var pty:String? = null
                var pop:String? = null
                var wav:String? = null
                var pcp:String? = null
                var reh:String? = null
                var sno:String? = null
                var tmx:String? = null
                var tmn:String? = null
                for(i in num until num_of_rows){
                    val item = jsonObj5.getJSONObject(num)
                    when(item.getString("category")){
                        "TMP" -> tmp = item.getString("fcstValue")
                        "UUU" -> uuu = item.getString("fcstValue")
                        "VVV" -> vvv = item.getString("fcstValue")
                        "VEC" -> vec = item.getString("fcstValue")
                        "WSD" -> wsd = item.getString("fcstValue")
                        "SKY" -> sky = item.getString("fcstValue")
                        "PTY" -> pty = item.getString("fcstValue")
                        "POP" -> pop = item.getString("fcstValue")
                        "WAV" -> wav = item.getString("fcstValue")
                        "PCP" -> pcp = item.getString("fcstValue")
                        "REH" -> reh = item.getString("fcstValue")
                        "SNO" -> sno = item.getString("fcstValue")
                        "TMX" -> tmx = item.getString("fcstValue")
                        "TMN" -> tmn = item.getString("fcstValue")
                    }
                    val list_time=item.getString("fcstTime")
                    if(list_time != timenow)
                        break
                    num++
                }
                Weathertxt.text = timenow+"시간의 기온은 "+tmp+"도, SKY는 "+sky+"위도 : "+nx+"경도 : "+ny //전에 받아오던 날씨값 출력하는 것의 id임(변경필요)



            }
            catch (e: Exception) { // 에러처리?
            }
        }
    }
}
