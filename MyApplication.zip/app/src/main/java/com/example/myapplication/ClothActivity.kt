package com.example.myapplication

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.layout_cloth.*

class ClothActivity : AppCompatActivity() {
    val allEntries : MutableMap<String, *> = MyApplication.prefs.getAll()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layout_cloth)

        var sum = 0F
        var num = 0F
        if (allEntries.isEmpty()){
            num = 1F
        }
        else {
            for((index,value) in allEntries){
                    sum += MyApplication.prefs.getFloat(index,0F)
                    num += 1F
            }
        }
        var result = sum / num

        toastbutton.setOnClickListener{
            intent.putExtra("sensitivity",result)
            Toast.makeText(applicationContext,"유저 민감도 : sum:${sum},num:${num}입니다.", Toast.LENGTH_SHORT).show()
        }
    }
}